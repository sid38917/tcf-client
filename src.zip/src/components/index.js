

import SlideHome from './SlideHome'
import ProductHome from './ProductHome'
import Fabric from './Fabric'
import Customize from './Customize'
import Register from './register'
import EndCustomize from './EndCustomize'

export {

SlideHome,
ProductHome,
Fabric, 
Customize,

EndCustomize

}