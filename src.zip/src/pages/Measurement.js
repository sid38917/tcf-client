
import React, {useState} from 'react';
import { useHistory, useParams } from 'react-router';
import { Row, Col, Image, Button, Modal, Select } from 'antd';
const {Option} = Select;

const Measurement = () => {
    const [viewModal, setViewModal] = useState(false) //false so that it doesnt pop up immediatelly
    const history = useHistory()
    const params = useParams();

    return (
        <>
            <Row>
                <h2>Measurement Options</h2>
            </Row>
            <Row gutter = {5} justify = 'center'>
                <Col span = {6} style = {{display: 'flex',flexDirection: 'column', justifyContent: 'center'}}>
                    <h3>Manual Input</h3>
                    <Image width = {200} src = 'https://i.ibb.co/9G0cDCG/image-1.png'/>
                        <Button style = {{backgroundColor: 'black', width: '100', color: 'black'}} onClick = {() => history.push(`/manual-measurement/${params.product}`)}>
                            Choose
                        </Button>
                    
                </Col>
                <Col span = {6} style = {{display: 'flex',flexDirection: 'column', justifyContent: 'center'}}>
                    <h3>STANDARD SIZING</h3>
                    <Image width = {200} src = 'https://i.ibb.co/m8XH3j2/image-2.png'/>
                        <Button style = {{backgroundColor: 'black', width: '100', color: 'black'}} onClick = {() => setViewModal(true)}>
                            Choose
                        </Button>
                    
                </Col>
            </Row>
            <Modal visible = {viewModal} footer  = {null} onCancel = {() => setViewModal(false)}>
                <h2>Standard Sizing</h2>
                <Row justify = 'center' style = {{display: 'flex', flexDirection: 'column', alignItems: 'center', alignContent: 'center'}}>
                    <h3>CHOOSE A FIT</h3>
                    <Select placeholder = 'FIT' style = {{width: 200, marginRight: '5px'}}>
                        <Option value = 'tight'>TIGHT</Option>
                        <Option value = 'loose'>LOOSE</Option>
                        <Option value = 'fitted'>FITTED</Option>
                    </Select>
                </Row>
                <Row justify = 'center' style = {{display: 'flex', flexDirection: 'column', alignItems: 'center', alignContent: 'center'}}>
                    <h3>CHOOSE A SIZE</h3>
                    <Select placeholder = 'SIZE' style = {{width: 200, marginRight: '5px'}}>
                        <Option value = 'XS'>XS</Option>
                        <Option value = 'S'>S</Option>
                        <Option value  = 'M'>M</Option>
                        <Option value = 'L'>L</Option>
                        <Option value = 'XL'>XL</Option>
                        <Option value = 'XXL'>XXL</Option>
                    </Select>
                </Row>
                <Row justify = 'center'>
                    <Button className = 'button-primary' onClick = {() => setViewModal(false)}>Save</Button>
                </Row>
            </Modal>
            
            
        </>
    )
}

export default Measurement