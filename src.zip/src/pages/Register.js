import React from 'react';
import {Form, Input, Button, Checkbox, Card} from 'antd'
import {Link} from 'react-router-dom'

const Register = () => {

    const onFinish = (values) => {
        console.log('Success =>', values)
    }

    const onFinishFailed = (errorInfo) => {
        console.log('Failed', errorInfo)
    }

    return (
       <Row justify = 'center'>
           <Card>
               <div>
                   <h2>Register</h2>
               </div>

               <Form name = 'basic' initialValues = {{remember = 'true'}} onFinish = {onFinish} onFinishFailed = {onFinishFailed}>
                   <Form.Item name = 'name' rules = {[{required: true, message: 'please input your name'}]}>
                       <Input placeholder= 'name'/>
                   </Form.Item>
                   <Form.Item name = 'email' rules = {[{required: true, message: 'please enter your email'}, {type = 'email', message: 'Email is not valid'}]}>
                       <Input placeholder = 'email'/>
                   </Form.Item>
                   <Form.Item name = 'password' rules = {[{required: true, message: 'please enter your password'}]}>
                       <Input.Password placeholder = 'password'/>
                   </Form.Item>

                   <Button className = 'button-primary' htmlType = 'submit'>
                       Submit
                   </Button>
                   <Link to = '/login'>Have an Account? Login here</Link>
               </Form>


           </Card>
       </Row>

    )
}

export default Register 