import React from 'react'
import { SlideHome, ProductHome} from '../components'

const Home = () => {
    return (
        <>
        <div>
            <SlideHome/>
            <ProductHome/>
        </div>
        </>
    )
}

export default Home