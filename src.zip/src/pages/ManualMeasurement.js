
// import React, {useState, useEffect} from 'react'
// import {Row, Col, Image, Button, Modal, Select, Input} from 'antd'
// import { CaretRightOutlined} from '@ant-design/icons';
// import Measurement from './Measurement';
// import {connect} from 'react-redux';
// import {setUser} from '../stores/action'
// import dataMeasurementShirt from '../data/dataMeasurementShirt'; 
// import dataMeasurementSuit from '../data/dataMeasurementSuit';
// import dataMeasurementTrouser from '../data/dataMeasurementTrouser';
// import dataMeasurementJacket from '../data/dataMeasurementJacket';
// import { useHistory, useParams } from 'react-router-dom';
// const params = useParams();
 
// const { Option } = Select;
// const ManualMeasurement = () => {
//     const [viewModal, setViewModal] = useState(false);
//     const [option, setOption] = useState([]);

//     const data = ["NECK", "CHEST", "WAIST", "HIP", "SEAT", "SHIRT LENGTH", "SHOULDER WIDTH", "ARM LENGTH", "WRIST"]
//     const [current, setCurrent] = useState(option[0]);
//     //const [modalLogin, setModalLogin] = 
//     const [input, setInput] = useState('')
//     useEffect(() => {
//         const {product} = params
//         if(product === 'suits') {
//             setOption(dataMeasurementSuit)
//             setCurrent(dataMeasurementSuit[0])
//         } else if (product === 'shirt'){
//             setOption(dataMeasurementShirt)
//             setCurrent(dataMeasurementShirt[0])
//         } else if (product === 'trousers') {
//             setOption(dataMeasurementTrouser)
//             setCurrent(dataMeasurementTrouser[0])
//         } else if (product === 'jacket') {
//             setOption(dataMeasurementJacket)
//             setCurrent(dataMeasurementJacket[0])
//         }
//     })
//     const onSave = () => {
//         if(!dataUser.token) {
//             return console.log('tidak bisa save')

//         } else {
//             return console.log('bisa save')
//         }
//     }

//     const inputData = (e) => {
//         console.log(e.target.value)
//         const newOptions = options.map((item) => {
//             if(item.name === current.name) {
//                 item.value = e.target.value
//             }
//             return item;
//         })
//     }

//     setOptions(newOptions)
//     return (
//         <>
//         <Modal visible = {modalLogin} onCancel= {() => setModalLogin(false)}>
//             <h2>Login Test</h2>
//         </Modal>
//         <Row justify = 'center'>
//             <h2>Manual Input Measurement</h2>

//         </Row>
//         <Row justify = 'center' style = {{margin: 20}}>
//             <Col span = {6}>
//                <iframe width="100%" height="553" src= {current.ur} allowfullscreen></iframe>
//             </Col>
//             <Col span = {4}>
//                 {
//                      option.map((item) => (
//                         <Button style = {{margin: '5px', backgroundColor: 'transparent', width: '100%'}} onClick={() => setCurrent(item)}> {/*when the bytton is clicked, it sets the currentData as shown above*/}
//                             <CaretRightOutlined/>{item} {/*to ge the black play button */}
//                         </Button>
//                     ))
//                 }
//             </Col> 
//         </Row>
//         <Row justify = 'center'>
//         <div style = {{display: 'flex', flexDirection: 'column', alignItems: 'center', alignContent:'center'}}>
//         <h3>{current.name}</h3>
//         <Input type = 'number' placeholder = 'Input Here' style = {{margin: 10}}/>
//         <Button className = 'button-primary' onClick = {onSave} onChange = {inputData}>
//             Save
//         </Button>
//         </div>
        
       
//         </Row>
//         </>
//     )

  
    
    
// }

// const mapStateToProps = state => {
//     const {User} = state;

//     return {
//         dataUser: User
//     }

// }

// const mapDispatchToProps = () => {

// }
// export default connect(mapStateToProps, mapDispatchToProps)(ManualMeasurement)
