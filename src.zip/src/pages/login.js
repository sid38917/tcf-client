import React, {useEffect} from 'react';
import {Row, Col, Card, Form, Input, Button, Checkbox} from 'antd';
import { Link, useHistory } from 'react-router-dom'
import {connect} from 'react-redux'
import {SetUser} from '../stores/action'


const Login = (props) => {
    const history = useHistory();
    const {dataUser, setUser} = props

    useEffect(() => {
        if(dataUser.token){
            history.push('/')
        }
    }, [dataUser])
    const onFinish = (values) => {
        localStorage.setItem('username', values.email) //sets the item
        console.log('success => ', values) //to print the user details in the console
        SetUser(`${values.email}`)
    }

    const onFinishFailed = (errorInfo) => {
        console.log('Failed =>', errorInfo)
    }

    //flex for flexbox
    return (
        
        <Row justify = 'center'>
            <Card style = {{width: '100vw', height: '100vw'}}>
                <div style = {{display: 'flex', justifyContent: 'center'}}> 
                    <h2>Login</h2>
                   </div>
                    <Form name = 'basic' initialValues = {{remember: true}} onFinish = {onFinish} onFinishFailed = {onFinishFailed}>
                        <Form.item name = 'email' rules = {[{required: true, message: 'please input your email'}, {type: 'email', message: 'email is not valid'}]}>
                            <Input placeholder = 'email'/>
                        </Form.item>
                        <Form.item name = 'password' rules = {[{required: true, message: 'please input your password'}]}>
                            <Input placeholder = 'password'/>
                        </Form.item>
                    <Button className = 'button-primary' htmlType = 'submit'>
                        Submit
                    </Button>
                    </Form>
                
            <Link to ='/register'>Dont have an Account? Register here</Link>
            </Card>
        </Row>
        
    )

}

const mapStateToProps = state => {
    const {User} = state;

    return {
        dataUser: User
    }
}

const mapDispatchToProps = {
    SetUser
}

export default connect(mapStateToProps, mapDispatchToProps)(Login)