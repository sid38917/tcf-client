const dataMeasurementTrouser = [
    {
        name: 'HIPS',
        url: 'https://www.youtube.com/embed/gD1X7F6hTCg'
    }, 
    
    {
        name: 'WAIST',
        url: 'https://www.youtube.com/embed/pAfsnaeEL8g'
    },
    {
        name: 'THIGHS',
        url: 'https://www.youtube.com/embed/A4TJ5HYNOD0'
    },
   
    {
        name: 'PANTS LENGTH',
        url: 'https://www.youtube.com/embed/DcEqqEI6s-0'
    },
    {
        name: 'CROTCH LENGTH',
        url: 'https://www.youtube.com/embed/7eqvTa2NnDM'
    }
]

export default dataMeasurementTrouser