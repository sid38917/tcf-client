const initialState = {
    data: [],
}

const CustomReducer = (state = initialState, action)  => {

    

    if(action.type === "SET_FABRIC") {
        console.log(action.payload)
        const {product} = action.params
        let newData = []

        

        if(state.data.length === 0){
            newData.push({
                product: product,
		        fabric: action.payload,
            })
        } else {
            const found = state.data.find((item) => item.product === product)

            if(!found) {
                newData = state.data
                newData.push({
                    product: product,
                    fabric: action.payload,
                })
            } else {
                newData = state.data.map((item) => {
                    if(item.product === product) {
                        item.fabric = action.payload
                    } 
                    return item
                })

            }
        }


        console.log(newData, 'new dataaa')
        return {
            ...state,
            data: newData
        }
    }

    return state
}

export default CustomReducer