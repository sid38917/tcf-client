

const SetUser = (data) => {


    return {
        type: 'SET_USER',
        payload: data,

    }
    
}

export {
    SetUser
}



