 const SetFabric = (data, params) => {
  

    return {
        type: 'SET_FABRIC',
        payload: data,
        params: params

    }
    
}

export  {SetFabric}
