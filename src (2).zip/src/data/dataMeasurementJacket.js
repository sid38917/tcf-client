const dataMeasurementJacket = [
    
        {    
            name: 'BODY LENGTH',
            url: 'https://www.youtube.com/embed/nhBT0_kNj6o'
        },
        {
            name: 'CHEST',
            url: 'https://www.youtube.com/embed/_PU-5WbBqT4'
        },
        {
            name: 'SHOULDER WIDTH',
            url: 'https://www.youtube.com/embed/97KHYVl1T1I'
        },
        {
            name: 'NECK',
            url: 'https://www.youtube.com/embed/D2yU81q_PH0'
        },
        {
            name: 'ARM HOLE',
            url: 'https://www.youtube.com/embed/olYmcl9SPkw'
        },
        {
            name: 'BICEPS',
            url: 'https://www.youtube.com/embed/HXCfRgdVc3k'
        },
        {
            name: 'HIPS',
            url: 'https://www.youtube.com/embed/pAfsnaeEL8g'
        },
        {
            name: 'WAIST',
            url: 'https://www.youtube.com/embed/gD1X7F6hTCg'
        }
        ,{   
            name: 'WAISTCOAT LENGTH',
            url: 'https://www.youtube.com/embed/Z9TPDjEq3OE'
        }

    
]

export default dataMeasurementJacket