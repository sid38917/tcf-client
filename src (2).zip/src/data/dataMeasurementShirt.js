const dataMeasurementShirt = [
  
    {    
        name: 'BODY LENGTH',
        url: 'https://www.youtube.com/embed/nhBT0_kNj6o'
    },
    {
        name: 'CHEST',
        url: 'https://www.youtube.com/embed/_PU-5WbBqT4'
    },
    {
        name: 'SHOULDER WIDTH',
        url: 'https://www.youtube.com/embed/97KHYVl1T1I'
    },
    {
        name: 'NECK',
        url: 'https://www.youtube.com/embed/D2yU81q_PH0'
    },
    {
        name: 'ARM HOLE',
        url: 'https://www.youtube.com/embed/olYmcl9SPkw'
    },
    {
        name: 'BICEPS',
        url: 'https://www.youtube.com/embed/HXCfRgdVc3k'
    }
]

export default dataMeasurementShirt;