const dataFabricShirt = [
    {
        url: "https://i.ibb.co/RNWqYz5/PIN-NON-0001-123016-PAUL-P-BLACK.jpg",
        name: "PAUL-P-BLACK",
        color:  "black",
        type: "plain"
    },
    {
        url: "https://i.ibb.co/QX53JL7/PIN-NON-0001-123017-MOORE-P-WHITE.jpg",
        name: "MOORE-P-WHITE",
        color: "white",
        type: "plain"
    },
    {
        url: "https://i.ibb.co/Q8DRbqg/PIN-NON-0001-123019-MOORE-P-PURPLE.jpg",
        name: "MOORE-PURPLE",
        color: "purple",
        type: "plain"
    },
    {
        url: "https://i.ibb.co/Z8GXwX5/PIN-NON-0001-123020-MOORE-P-BLUE.jpg",
        name: "MOORE-BLUE",
        color: "blue",
        type: "plain"
    },
    {
        url: "https://i.ibb.co/NV98qFG/PIN-NON-0001-123021-MOORE-P-WHITE.jpg",
        name: "MOORE-WHITE",
        color: "white",
        type: "plain"
    },
    
    {
        url: "https://i.ibb.co/4M5rGxS/PIN-NON-0001-123023-MOORE-P-PURPLE.jpg",
        name: "MOORE-PURPLE", 
          color: "purple",
        type: "plain"
    },
    
    ,      {
        url: "https://i.ibb.co/b2RsWfF/PIN-NON-0001-123032-VANESSA-P-WHITE.jpg",
        name: "VANESSA-WHITE",  
          color: "white",
        type: "plain"
    },
    {
        url: 'https://i.ibb.co/S3HfpT7/PIN-NON-0001-123033-VANESSA-P-GREY.jpg',
        name: 'VANESSA-GREY',
        color: 'white',
        type: 'plain'
    },{
        url: 'https://i.ibb.co/pR0TQ2r/PIN-NON-0001-123035-VANESSA-P-PURPLE.jpg',
        name: 'VANESSA-PURPLE',
        color: '',
        type: ''
    },{
        url: 'https://i.ibb.co/JFH7zrm/PIN-NON-0001-123044-SIMON-C-BLUE.jpg',
        name: 'SIMON-BLUE',
        color: 'blue',
        type: 'checks'
    },{
        url: 'https://i.ibb.co/Fq2f8xT/PIN-NON-0001-123045-SIMON-C-BLUE-PURPLE.jpg',
        name: 'SIMON-BLUE-PURPLE',
        color: 'blue',
        type: 'checks'
    },{
        url: 'https://i.ibb.co/Q9DwtDF/PIN-NON-0001-123048-MITRA-C-BLUE-PINK.jpg',
        name: 'MITRA-BLUE-PINK',
        color: 'blue',
        type: 'checks'
    },{
        url: 'https://i.ibb.co/8d7f2Ch/PIN-NON-0001-123049-MITRA-S-BLUE.jpg',
        name: 'MITRA-BLUE-STRIPES',
        color: 'blue',
        type: 'stripes'
    },{
        url: 'https://i.ibb.co/SQRBXqV/PIN-NON-0001-123062-ALYSSA-P-WHITE.jpg',
        name: 'ALYSSA-WHITE',
        color: 'white',
        type: 'plain'
    },
    {
        url: 'https://i.ibb.co/tCCn7M4/PIN-NON-0001-128001-OXFORD-SILVER-DP-P-WHITE.jpg',
        name: 'OXFORD-SILVER-WHITE',
        color:'white',
        type: 'plain'
    }, 
    {
        url: 'https://i.ibb.co/dGTt3NG/PIN-NON-0001-128003-COLLINS-DP-C-BLUE-1.jpg',
        name: 'OXFORD-SILVER-BLUE',
        color: 'blue',
        type: 'plain'
    },
    {
        url: 'https://i.ibb.co/6BvZzMP/PIN-NON-0001-128031-HOU-BLUE.jpg',
        name: 'BLUE',
        color: 'blue',
        type: 'houndstooth'
    },
    {
        url: 'https://i.ibb.co/n3rLJL7/PIN-NON-0001-128048-CARAIBI-DP-S-PINK-BLUE.jpg',
        name: 'CARAIBI',
        color: 'pink',
        type: 'stripes' 
    }

]


export default dataFabricShirt