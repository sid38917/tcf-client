const dataMeasurementSuit = [
    {    
        name: 'BODY LENGTH',
        url: 'https://www.youtube.com/embed/nhBT0_kNj6o'
    },
    {
        name: 'CHEST',
        url: 'https://www.youtube.com/embed/_PU-5WbBqT4'
    },
    {
        name: 'SHOULDER WIDTH',
        url: 'https://www.youtube.com/embed/97KHYVl1T1I'
    },
    {
        name: 'NECK',
        url: 'https://www.youtube.com/embed/D2yU81q_PH0'
    },
    {
        name: 'ARM HOLE',
        url: 'https://www.youtube.com/embed/olYmcl9SPkw'
    },
    {
        name: 'BICEPS',
        url: 'https://www.youtube.com/embed/HXCfRgdVc3k'
    },
    {
        name: 'HIPS',
        url: 'https://www.youtube.com/embed/pAfsnaeEL8g'
    },
    {
        name: 'WAIST',
        url: 'https://www.youtube.com/embed/gD1X7F6hTCg'
    }
    ,{   
        name: 'WAISTCOAT LENGTH',
        url: 'https://www.youtube.com/embed/Z9TPDjEq3OE'
    }
,
{
    name: 'HIPS',
    url: 'https://www.youtube.com/embed/gD1X7F6hTCg'
}, 

{
    name: 'WAIST',
    url: 'https://www.youtube.com/embed/pAfsnaeEL8g'
},
{
    name: 'THIGHS',
    url: 'https://www.youtube.com/embed/A4TJ5HYNOD0'
},

{
    name: 'PANTS LENGTH',
    url: 'https://www.youtube.com/embed/DcEqqEI6s-0'
},
{
    name: 'CROTCH LENGTH',
    url: 'https://www.youtube.com/embed/7eqvTa2NnDM'
}
  
]

export default dataMeasurementSuit