import React from 'react'
import { SlideHome, ProductHome} from '../components'

const Home = () => {
    return (
        <>
        <div>
            <SlideHome/>
         
        </div>
        </>
    )
}

export default Home